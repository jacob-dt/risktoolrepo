from dotenv import load_dotenv
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

load_dotenv()

app = Flask(__name__, template_folder='templates', static_folder='static', static_url_path='/')
app.config.from_object('config.Config')
db = SQLAlchemy(app)

from routes import *

if __name__ == '__main__':
    app.run(debug=True)
