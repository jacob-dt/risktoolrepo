from flask import render_template, request, redirect, url_for, flash, session
from app import app, db
from models import Plant, Project, Risk
import datetime
from sqlalchemy import or_

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        project_tier = request.form.get('project_tier')
        new_site = request.form.get('new_site')
        new_equipment = request.form.get('new_equipment')

        session['search_criteria'] = {
            'project_tier': project_tier,
            'new_site': new_site,
            'new_equipment': new_equipment
        }

        return redirect(url_for('search_results'))

    return render_template('search.html')

@app.route('/search_results')
def search_results():
    search_criteria = session.get('search_criteria', {})
    project_tier = search_criteria.get('project_tier')
    new_site = search_criteria.get('new_site')
    new_equipment = search_criteria.get('new_equipment')

    query = db.session.query(Risk).join(Project).filter(
        (Project.project_tier == project_tier) |
        (Project.new_site_or_existing_site == new_site) |
        (Project.new_equipment_or_upgrade == new_equipment)
    )

    risks = query.all()

    results = {}
    for risk in risks:
        plant = risk.project.plant
        project = risk.project
        matched_criteria = []
        if project.project_tier == project_tier:
            matched_criteria.append('Project Tier')
        if project.new_site_or_existing_site == new_site:
            matched_criteria.append('New Site/Existing Site')
        if project.new_equipment_or_upgrade == new_equipment:
            matched_criteria.append('New Equipment/Upgrade')

        if plant not in results:
            results[plant] = {}
        if project not in results[plant]:
            results[plant][project] = {'risks': [], 'match_count': len(matched_criteria), 'matched_criteria': matched_criteria}
        results[plant][project]['risks'].append(risk)

    # Sort projects by the number of matches in descending order
    for plant, projects in results.items():
        sorted_projects = dict(sorted(projects.items(), key=lambda item: item[1]['match_count'], reverse=True))
        results[plant] = sorted_projects

    return render_template('search_results.html', results=results)


@app.route('/add')
def add():
    return render_template('add.html')

@app.route('/add_plant', methods=['GET', 'POST'])
def add_plant():
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        plant_category = request.form['plant_category']
        plant_status = request.form['plant_status']
        country = request.form['country']
        state = request.form['state']
        city = request.form['city']
        notes = request.form['notes']
        created_date = request.form['created_date']
        
        new_plant = Plant(
            name=name,
            description=description,
            plant_category=plant_category,
            plant_status=plant_status,
            country=country,
            state=state,
            city=city,
            notes=notes,
            created_date=created_date
        )
        
        db.session.add(new_plant)
        db.session.commit()
        
        flash('Plant added successfully!', 'success')
        return redirect(url_for('add_plant'))
    
    plants = Plant.query.all()
    return render_template('add_plant.html', plants=plants)

@app.route('/delete_plant/<int:plant_id>', methods=['POST'])
def delete_plant(plant_id):
    plant = Plant.query.get_or_404(plant_id)
    db.session.delete(plant)
    db.session.commit()
    flash('Plant deleted successfully!', 'success')
    return redirect(url_for('add_plant'))

@app.route('/add_project', methods=['GET', 'POST'])
def add_project():
    if request.method == 'POST':
        plant_id = request.form['plant_id']
        project_tier = request.form['project_tier']
        new_equipment_or_upgrade = request.form['new_equipment_or_upgrade']
        new_site_or_existing_site = request.form['new_site_or_existing_site']
        project_name = request.form['project_name']
        description = request.form['description'] or None
        project_category = request.form['project_category']
        project_sub_category = request.form['project_sub_category'] or None
        project_3rd_category_tier = request.form['project_3rd_category_tier'] or None
        address = request.form['address'] or None
        country = request.form['country'] or None
        city = request.form['city'] or None
        state = request.form['state'] or None
        zip = request.form['zip'] or None
        created_date = request.form['created_date']

        new_project = Project(
            plant_id=plant_id,
            project_tier=project_tier,
            new_equipment_or_upgrade=new_equipment_or_upgrade,
            new_site_or_existing_site=new_site_or_existing_site,
            project_name=project_name,
            description=description,
            project_category=project_category,
            project_sub_category=project_sub_category,
            project_3rd_category_tier=project_3rd_category_tier,
            address=address,
            country=country,
            city=city,
            state=state,
            zip=zip,
            created_date=created_date
        )
        
        db.session.add(new_project)
        db.session.commit()
        
        flash('Project added successfully!', 'success')
        return redirect(url_for('add_project'))
    
    plants = Plant.query.all()
    projects = Project.query.all()
    return render_template('add_project.html', plants=plants, projects=projects)

@app.route('/delete_project/<int:project_id>', methods=['POST'])
def delete_project(project_id):
    project = Project.query.get_or_404(project_id)
    db.session.delete(project)
    db.session.commit()
    flash('Project deleted successfully!', 'success')
    return redirect(url_for('add_project'))

@app.route('/add_risk', methods=['GET', 'POST'])
def add_risk():
    if request.method == 'POST':
        project_id = request.form['project_id']
        created_date = request.form['created_date']
        risk_description = request.form['risk_description']
        risk_category = request.form['risk_category']
        risk_owner = request.form['risk_owner'] or None
        impact_description = request.form['impact_description']
        risk_probability = int(request.form['risk_probability'])
        risk_impact = int(request.form['risk_impact'])
        total_cost_impact = request.form['total_cost_impact']
        risk_mitigation_strategy = request.form['risk_mitigation_strategy']
        total_risk_mitigation_impact = request.form['total_risk_mitigation_impact']
        critical_path_schedule_impact = request.form['critical_path_schedule_impact'] or None
        activity_delay_weeks = request.form['activity_delay_weeks'] or None
        rationale_for_change_or_closure = request.form['rationale_for_change_or_closure'] or None

        new_risk = Risk(
            project_id=project_id,
            created_date=created_date,
            risk_description=risk_description,
            risk_category=risk_category,
            risk_owner=risk_owner,
            impact_description=impact_description,
            risk_probability=risk_probability,
            risk_impact=risk_impact,
            total_cost_impact=total_cost_impact,
            risk_mitigation_strategy=risk_mitigation_strategy,
            total_risk_mitigation_impact=total_risk_mitigation_impact,
            critical_path_schedule_impact=critical_path_schedule_impact,
            activity_delay_weeks=activity_delay_weeks,
            rationale_for_change_or_closure=rationale_for_change_or_closure
        )

        db.session.add(new_risk)
        db.session.commit()

        flash('Risk added successfully!', 'success')
        return redirect(url_for('add_risk'))

    projects = Project.query.all()
    risks = Risk.query.all()
    return render_template('add_risk.html', projects=projects, risks=risks)

@app.route('/delete_risk/<int:risk_id>', methods=['POST'])
def delete_risk(risk_id):
    risk = Risk.query.get_or_404(risk_id)
    db.session.delete(risk)
    db.session.commit()
    flash('Risk deleted successfully!', 'success')
    return redirect(url_for('add_risk'))

@app.route('/view_all')
def view_all():
    plants = Plant.query.all()
    projects = Project.query.all()
    risks = Risk.query.all()
    return render_template('view_all.html', plants=plants, projects=projects, risks=risks)

@app.route('/risk/<int:risk_id>')
def risk_detail(risk_id):
    risk = Risk.query.get_or_404(risk_id)
    return render_template('risk_detail.html', risk=risk)