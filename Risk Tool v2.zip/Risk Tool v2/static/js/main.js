
// Back Button Function
function goBack() {
    window.history.back();
}

