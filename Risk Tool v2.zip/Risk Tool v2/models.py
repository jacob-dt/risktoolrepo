from app import db
from sqlalchemy.ext.hybrid import hybrid_property

class Plant(db.Model):
    __tablename__ = 'plants'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    plant_category = db.Column(db.Enum('Automotive', 'Can', 'Specialty B&C', 'Specialty Finishing', 'Other NNA (non-plant)'), nullable=False)
    plant_status = db.Column(db.Enum('Global', 'NA Asia', 'NE Europe', 'NNA North America', 'NSA South America'), nullable=False)
    country = db.Column(db.String(255), nullable=False)
    state = db.Column(db.String(255))
    city = db.Column(db.String(255), nullable=False)
    notes = db.Column(db.Text)
    created_date = db.Column(db.Date, nullable=False)
    projects = db.relationship('Project', backref='plant', cascade="all, delete-orphan")

class Project(db.Model):
    __tablename__ = 'projects'
    id = db.Column(db.Integer, primary_key=True)
    plant_id = db.Column(db.Integer, db.ForeignKey('plants.id'), nullable=False)
    project_tier = db.Column(db.Enum('Tier 1', 'Tier 2', 'Tier 3', 'Tier 4', 'Tier 5'), nullable=False)
    new_equipment_or_upgrade = db.Column(db.Enum('New Equipment', 'Upgrade to Existing'), nullable=False)
    new_site_or_existing_site = db.Column(db.Enum('New Site', 'Existing Site'), nullable=False)
    project_name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    project_category = db.Column(db.Enum('1.1 Capacity Expansion - Greenfield (CE-G)', '1.2 Capacity Expansion Brownfield (CE-B)', '1.3 Cost Savings (CS)', '2.1 General Maintenance (GM) (recurring 3 - 5 yrs)', '2.2 One-Time Non Return Based (OTN) (Protecting People, Process, Environment & Equipment)', '2.3 R&D (RD)', '2.4 IT (IT)'), nullable=False)
    project_sub_category = db.Column(db.Enum('1.1 CEG.01 - Rolling Expansion', '1.1 CEG.02 - Casting/Recycling Expansion', '1.1 CEG.03 - Finishing Expansion', '1.1 CEG.04 - Integrated Plant', '1.2 CEB.01 - Rolling Expansion', '1.2 CEB.02 - Casting/Recycling Expansion', '1.2 CEB.03 - Finishing Expansion', '1.2 CEB.04 - Integrated Plant', '1.3 CS.01 - Digital', '1.3 CS.02 - Fast Payback', '1.3 CS.03 - Plant of the Future', '1.3 CS.04 - Energy', '1.3 CS.05 - Other Cost Savings', '2.1 GM.01 - Base "0"', '2.1 GM.02 - Maintenance & Reliability', '2.1 GM.03 - Quality Sustainment & Improvement', '2.1 GM.04 - Other', '2.2 OTN.01 - EHS', '2.2 OTN.02 Maintenance & Reliability', '2.2 OTN.03 - Property Loss Control', '2.2 OTN.04 - Energy', '2.2 OTN.05 - Sustainability Projects', '2.2 OTN.06 - Cyber-Security', '2.2 OTN.07 - Quality Sustainment & Improvement', '2.2 OTN.08 - Digital', '2.2 OTN.09 - Plant of the Future', '2.2 OTN.10 - Other', '2.3 RD.01 - R&D', '2.4 IT.01 - IT'), nullable=True)
    project_3rd_category_tier = db.Column(db.Enum('GM 1.1 - Reliability (Major Furnace Rebuilds)', 'GM 1.2 - Consumable Products (Mill Rolls)', 'GM 1.3 - Consumable Products (Ingot molds)', 'GM 1.4 - Consumable Products (Other - bearing, Skimming/Drainage Pans, etc)', 'GM 2.1 - Critical Spare', 'GM 2.2 - Process Equipment Sustainment & Improvement', 'GM 2.3 - Physical Infrastructure Sustainment & Improvement', 'GM 2.4 - Automation Improvement & Obsolescence', 'GM 2.5 - Mobile Equipment', 'OTN 1.1 - Combustible Dust', 'OTN 1.2 - Serious Injury/Fatality', 'OTN 1.3 - Cranes', 'OTN 1.4 - Environmental', 'OTN 1.5 - Other EHS', 'OTN 2.1 - Critical Spares', 'OTN 2.2 - Process Equipment Sustainment & Improvement', 'OTN 2.3 - Physical Infrastructure Sustainment & Improvement', 'OTN 2.4 - Automation Improvement & Obsolescence', 'OTN 2.5 - Mobile Equipment', 'OTN 4.1 - Energy Infrastructure', 'OTN 5.1 - Carbon Reduction', 'OTN 5.2 - Water Usage Reduction', 'OTN 5.3 - Waste Reduction', 'OTN 5.4 - Renewable Energy'), nullable=True)
    address = db.Column(db.String(255), nullable=True)
    country = db.Column(db.String(255), nullable=True)
    city = db.Column(db.String(255), nullable=True)
    state = db.Column(db.String(255), nullable=True)
    zip = db.Column(db.String(10), nullable=True)
    created_date = db.Column(db.Date, nullable=False)
    risks = db.relationship('Risk', backref='project', cascade="all, delete-orphan")

class Risk(db.Model):
    __tablename__ = 'risks'
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=False)
    created_date = db.Column(db.Date, nullable=False)
    risk_description = db.Column(db.Text, nullable=False)
    risk_category = db.Column(db.Enum('01 Quality', '02 Technology', '03 Design', '04 Scope', '05 Safety', '06 Management', '07 Construction Equipment', '08 Commercial', '09 Labor', '10 Supply Chain', '11 Regulatory', '12 Environmental', '13 Natural Hazards', '14 Reputational', '15 Other'), nullable=False)
    risk_owner = db.Column(db.String(255), nullable=True)
    impact_description = db.Column(db.Text, nullable=False)
    risk_probability = db.Column(db.Integer, nullable=False)
    risk_impact = db.Column(db.Integer, nullable=False)
    total_cost_impact = db.Column(db.Numeric(15, 2), nullable=False)
    risk_mitigation_strategy = db.Column(db.Text, nullable=False)
    total_risk_mitigation_impact = db.Column(db.Numeric(15, 2), nullable=False)
    critical_path_schedule_impact = db.Column(db.Enum('Yes', 'No'), nullable=True)
    activity_delay_weeks = db.Column(db.Integer, nullable=True)
    rationale_for_change_or_closure = db.Column(db.Text, nullable=True)
    risk_factor = db.Column(db.Numeric(10, 2), nullable=False, server_default=db.text('risk_probability * risk_impact'))  # Calculated in the database
